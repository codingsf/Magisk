# Magisk Manager
The project can only be compiled on Android Studio Version 2.2.0+ (currently in beta)

# Prebuild Binaries
### libbusybox.so
Static BusyBox binary by @yashdsaraf  
Link and source: http://forum.xda-developers.com/showthread.php?t=3348543

### libzip.so
Static ndk-built info-zip  
NDK makefiles: https://github.com/cloudchou/ndkzip  
Info-Zip source: https://sourceforge.net/projects/infozip/  
bzip2 source: http://www.bzip.org/
